

export const hellowSay = (arg:string) => `HEllow i new is ${  arg}`

