import { Story } from "@storybook/api";
import "app/style/index.scss";

export const StyleDecorator = (story: () => Story) => story();
