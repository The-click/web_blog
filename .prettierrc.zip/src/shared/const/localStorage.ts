export const USER_LOCALSTORAGE_KEY = "user";
export const ARTICLE_VIEW_LOCALSTORAGE_KEY = "articles_view";
