import { LangSwitcher } from "./ui/LangSwitcher";

export {LangSwitcher}