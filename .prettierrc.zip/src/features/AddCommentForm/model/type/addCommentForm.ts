export interface AddCommentFormSchema {
    isLoading?: boolean;
    error?: string;
    text: string;
}
