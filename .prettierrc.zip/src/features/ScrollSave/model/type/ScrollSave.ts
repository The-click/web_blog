export type ScrollRecordSchema = Record<string, number>;

export interface ScrollSaveSchema {
    scroll: ScrollRecordSchema;
}
