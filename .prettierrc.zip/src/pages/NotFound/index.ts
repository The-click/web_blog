import { NotFound } from "./ui/NotFound";

export { NotFound };
