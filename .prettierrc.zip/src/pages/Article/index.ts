export { ArticlePageLazy as ArticlePage } from "./ui/ArticlePage.async";

export { ArticlePageSchema } from "./model/type/articlePageSchema";
