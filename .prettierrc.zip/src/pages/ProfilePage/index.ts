import { ProfilePageLazy } from "./ui/ProfilePage.async";

export { ProfilePageLazy as ProfilePage } from "./ui/ProfilePage.async";
