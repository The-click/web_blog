import { MainPageLazy } from "./ui/MainPage.async";

export {MainPageLazy as MainPage};