import { AboutPageLazy } from "./ui/AboutPage.async";

export{
    AboutPageLazy as AboutPage,
}